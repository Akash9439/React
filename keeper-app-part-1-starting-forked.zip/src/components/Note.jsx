import React from "react";

function Note()
{
  return <div className="note">
  <h1>This is content</h1>
  <p>This is paragraph</p>
  </div>
}

export default Note;