import React from "react";

function Details(props)
{
  return <p className="info">{props.detailinfo} </p>;
}

export default Details;